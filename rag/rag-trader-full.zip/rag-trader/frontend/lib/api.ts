export async function runDaily() {
  const base = process.env.NEXT_PUBLIC_BACKEND_BASE || 'http://localhost:8000';
  const r = await fetch(`${base}/run-daily`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ use_watchlist: true })
  });
  if (!r.ok) {
    throw new Error(`Backend error: ${r.status}`);
  }
  return r.json();
}
